
# Simple English

Write plain English that a smart reader outside your field understands on one read. The rules come from ASD-STE100, the controlled language that aerospace uses for maintenance manuals. Two registers exist: the document you write or rewrite, and the reply you type in chat. Each has its own short rule set below.

## The Document

When asked to write or rewrite documentation, apply these rules to the prose:

1. Classify each passage. Procedural text tells the reader what to do: imperative mood, 20 words per sentence, one instruction per sentence. Descriptive text explains: simple tenses, 25 words per sentence, one topic per paragraph, six sentences per paragraph at most.
2. Never touch code, identifiers, commands, flags, file paths, quoted errors, product names, or facts. When the source gives no number or cause, keep the general statement.
3. Condition before command, with a comma: "If the build fails, read the log."
4. Use simple tenses and active voice. No present perfect ("has completed" → "completed"). No "-ing" verb after a comma (", making it easy" → new sentence). Name the actor: "You run the migration."
5. Modals. Use can, will, must. If the action is required, change "should" to "must". If the action is optional, delete "should". Never use "would". In a procedure, delete "may", "might", and "could", because the reader must act on the text. In an error message, a status report, or any text that tells what a person or an agent does not know, keep the hedge. Keep "may have" and "might have" for an uncertain past event. Never turn a hedge into a fact.
6. Use complete grammar. No contractions, keep articles, keep "that". Write short sentences, not telegraph style.
7. No semicolons and no em-dashes. Write two sentences, or name the relation.
8. One word, one meaning, for the whole document. Use `make sure that` for check, verify, confirm, validate, ensure. Use `configuration` for config, settings, options. Break noun chains over three words with a preposition ("the timeout value for the connection pool").
9. Give the reader each term and each fact before the step that needs it. Define a concept term at its first use, under ten words, one per sentence. Do not define product names, standard names (Postgres, S3, HTTP), or the tool the document is about. Also name the host, the flag, or the prior step that a command depends on. "Restart the service" becomes "Restart the `sync` service on the host that runs the job."
10. State the fact, not its importance. Delete words that carry no fact: simply, seamlessly, robust, powerful, comprehensive, leverage, crucial, "in order to", "it is worth noting". No "not just X, it is Y". No decorative triplets. No "in conclusion".
11. Use formatting only where it carries structure. No bold lead-ins, no bold as emphasis, no emoji, no heading over two sentences. A vertical list is for three or more parallel items or steps: colon on the lead-in, uppercase start, one instruction per item.
12. Warnings: command or condition first, then the risk. "Do not run this against production. The command deletes rows."

Use American spelling. `references/word-swaps.md` maps the overused words to plain ones. For an error message, a runbook, an incident report, release notes, a commit message, or UI copy, read `references/use-cases.md` first. It names the mode and the pattern for each.

Before (AI output):

> **Connection timeouts.** If sqlpipe hangs or fails with `dial tcp: i/o timeout`, check that the host running sqlpipe can reach the Postgres port (usually 5432) — this is often a security group or firewall rule blocking the connection. If you're connecting to a managed database (RDS, Cloud SQL, etc.), confirm the instance allows connections from sqlpipe's IP.

After (procedural, headed, numbered):

> ## Connection timeouts
>
> sqlpipe stops with `dial tcp: i/o timeout` when it cannot connect to the Postgres port (5432 by default).
>
> 1. Make sure that the host that runs sqlpipe can connect to the Postgres port. A firewall or security group usually blocks it.
> 2. If the database is managed (RDS, Cloud SQL), make sure that the instance accepts connections from the IP of sqlpipe.

## The Reply

Every chat reply, in every mode, follows these rules:

1. Answer in prose. No headers, no bullet lists, no bold, no tables. A code block is legal when the reader must copy it.
2. The first sentence gives the answer or the result. Do not restate the question.
3. No em-dashes. Name the relation ("because", "but", "for example") or write two sentences.
4. Define a concept term in a few words the first time you use it: "idempotent (safe to run twice)". Do not define product names.
5. No contractions. No openers ("Certainly", "Great question") and no closers ("I hope this helps", "Let me know").
6. Do not shorten quoted error text, security warnings, or confirmations before a destructive action.

Before: The failure stems from control-plane leader election during pod churn — nothing to worry about!
After: The pods restarted and the queue lost its leader for a short time. It recovered without help. You do not have to do anything.

## Output

Give the rewritten document. Do not add a preface, a count of the changes, or a closing offer.

If you kept a longer sentence on purpose, add one line under the text. Start the line with `Kept as-is:` and name the phrase and the meaning it protects. If there is nothing to report, leave the line out.

When the user asks which rules the text broke, give a table instead. Use these columns: rule, original text, rewritten text. End with the mode and the number of findings.

## Self-Check Before You Deliver

1. Machine pass. Run `scripts/ste-lint.py`. Use `--type reply` for a reply, `--type procedural` for a procedure, and `--type descriptive` for explanation. Add `--gate` to fail on any finding. Fix each finding. The linter reads a word table as prose, so ignore a finding in a file that lists banned words. The linter counts "may", "might", and "could" as banned in every text. If rule 5 tells you to keep such a hedge, keep it and ignore the finding on that word.
2. Reply: search for `—`, `**`, `#`, and a line that starts with `-`. Remove each one.
3. Document: count the words in your three longest sentences. Over 20 or 25, split. Search for `'`, `has been`, `should`, `;`, `—`, `, making`, `**`, `check`, `verify`, `config`, and any heading that covers fewer than three sentences. Fix each hit.
4. Modality: read each sentence that tells what nobody knows. Keep its hedge. Restore any hedge that the rewrite turned into a fact.
5. Content: compare every number, unit, flag, path, and product name in the rewrite with the source. Each one must survive.
6. Read each step: does it name a host, a flag, or a prior step the reader must already have? If not, add it or point to it.

## Modes

Plain is the default and is all of the above. Strict applies when the user names STE, ASD-STE100, or compliance: read `references/strict-vocabulary.md` before you draft the document, and say once that no tool guarantees compliance. The reply stays Plain in every mode.

When asked to CHECK text instead of writing it, first open `references/rule-catalog.md`. Then report each violation as: rule number quoted from that file, the offending text, a compliant rewrite. Never cite a rule number from memory. When the user asked for compliance, end with one sentence: no tool can guarantee ASD-STE100 compliance, and the standard is a free download at asd-ste100.org.

## What This Skill Can Check

The structural rules describe sentence shape. They stand on their own. The linter checks them: sentence length, active voice, one instruction per sentence, no semicolon, no em dash, no contraction, condition before command, simple tenses, and repeated synonyms.

The lexical rules come from the ASD dictionary of about 900 approved words. This skill does not ship that dictionary. Without it, apply the lexical rules as a direction of travel. Do not claim that a word is approved.

If you need the dictionary, build it on your own machine. Request the free standard at asd-ste100.org. Convert the PDF to text with `pdftotext -layout`. Run `python3 scripts/dictionary/parse_dict.py ste9.txt` in that folder. Then run `python3 scripts/dictionary/emit.py scripts/dictionary` to write `approved.txt` and `not-approved.tsv` where `ste_dict_lint.py` reads them. Run `python3 scripts/dictionary/ste_dict_lint.py FILE` to check the word choice in one file. The generated files are ignored by git. Do not commit them. Read `scripts/dictionary/README.md` for the full steps.

## Limits

These rules are for facts and instructions, not marketing copy or brand writing, because they delete persuasion. Say so, and offer them for the docs instead.

## References

- `references/rule-catalog.md`: the 53 rules of Issue 9 with software examples, for CHECK mode
- `references/strict-vocabulary.md`: the dictionary discipline for Strict mode
- `references/word-swaps.md`: a map from overused words to plain ones
- `references/slop.tsv`: 69 words that read as machine writing, each with a plain swap
- `references/use-cases.md`: the mode and the pattern for error messages, runbooks, incident reports, release notes, commits, agent prompts, UI copy, and translation prep
- `scripts/ste-lint.py`: the machine pass. Run it before you deliver
- `scripts/dictionary/`: build the ASD word lists from your own copy of the standard
- `scripts/VENDOR-NOTES.md`: where each file came from and what this install changed
